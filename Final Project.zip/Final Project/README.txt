In this Zip File was the final project that three of my classmates and I did in MATLAB for our BME 154
(Biomedical Electronic Measurements) class. There were 4 problems that we were asked to do and the MATLAB code for 
each problem are in separate folders. For some of the problems there are multiple MATLAB files. The folders also include
data files that we were given that we needed to import into our MATLAB files so these data files are necessary for 
the MATLAB files to run. 

The graphs and data that we produced using the MATLAB files are compiled into a word document called Result.docx. 
This file will explain what all the graphs and data we produced mean. 

Please let me know if you have any questions or if any of the code doesn't work. 